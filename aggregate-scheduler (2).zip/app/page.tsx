"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { ScheduleUploader } from "@/components/schedule-uploader"
import { ScheduleReport } from "@/components/schedule-report"
import type { ScheduleData } from "@/types/schedule"
import { Truck, RotateCcw } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

// Auto-save functionality
const loadFromLocalStorage = (): { scheduleData: ScheduleData | null; dispatcherNotes: string } => {
  try {
    const saved = localStorage.getItem("spallina-schedule-autosave")
    if (saved) {
      const parsed = JSON.parse(saved)
      console.log("📂 Loaded from localStorage, last saved:", parsed.lastSaved)
      return {
        scheduleData: parsed.scheduleData || null,
        dispatcherNotes: parsed.dispatcherNotes || "",
      }
    }
  } catch (error) {
    console.error("❌ Failed to load from localStorage:", error)
  }
  return { scheduleData: null, dispatcherNotes: "" }
}

const clearLocalStorage = () => {
  try {
    localStorage.removeItem("spallina-schedule-autosave")
    console.log("🗑️ Cleared localStorage")
  } catch (error) {
    console.error("❌ Failed to clear localStorage:", error)
  }
}

export default function Home() {
  const [scheduleData, setScheduleData] = useState<ScheduleData | null>(null)
  const [hasSavedData, setHasSavedData] = useState(false)

  // Check for saved data on component mount
  useEffect(() => {
    const saved = loadFromLocalStorage()
    if (saved.scheduleData) {
      setHasSavedData(true)
    }
  }, [])

  const handleDataProcessed = (data: ScheduleData) => {
    console.log("Data processed:", data)
    setScheduleData(data)
    setHasSavedData(false) // Clear the saved data flag when new data is loaded
  }

  const handleUpdateData = (updatedData: ScheduleData) => {
    setScheduleData(updatedData)
  }

  const handleLoadSavedData = () => {
    const saved = loadFromLocalStorage()
    if (saved.scheduleData) {
      setScheduleData(saved.scheduleData)
      setHasSavedData(false)
    }
  }

  const handleStartFresh = () => {
    clearLocalStorage()
    setScheduleData(null)
    setHasSavedData(false)
  }

  if (scheduleData) {
    return <ScheduleReport data={scheduleData} onUpdateData={handleUpdateData} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-4">
            <Image
              src="/images/spallina-logo.jpg"
              alt="Spallina Materials Logo"
              width={80}
              height={80}
              className="rounded-lg shadow-md"
            />
            <div>
              <h1 className="text-4xl font-bold text-gray-900">Spallina Materials</h1>
              <p className="text-xl text-gray-600">Aggregate and Concrete Scheduler</p>
            </div>
          </div>
          <Link href="/trucks">
            <Button variant="outline" className="flex items-center gap-2 bg-transparent">
              <Truck className="h-4 w-4" />
              Manage Trucks
            </Button>
          </Link>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">Upload Schedule File</h2>
              <p className="text-gray-600">Upload your Excel or CSV file to generate the daily trucking schedule</p>
            </div>

            {/* Saved data notification */}
            {hasSavedData && (
              <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-medium text-blue-900">Previous Session Found</h3>
                    <p className="text-blue-700">You have unsaved changes from a previous session.</p>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleLoadSavedData} className="bg-blue-600 hover:bg-blue-700">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Continue Previous Session
                    </Button>
                    <Button onClick={handleStartFresh} variant="outline">
                      Start Fresh
                    </Button>
                  </div>
                </div>
              </div>
            )}

            <ScheduleUploader onDataProcessed={handleDataProcessed} />
          </div>
        </div>
      </div>
    </div>
  )
}

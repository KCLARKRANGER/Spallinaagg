"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, FileSpreadsheet, AlertCircle, CheckCircle } from "lucide-react"
import { processExcelFile } from "@/lib/excel-processor"
import { processCSVFile } from "@/lib/csv-parser"
import type { ScheduleData } from "@/types/schedule"

interface ScheduleUploaderProps {
  onDataProcessed: (data: ScheduleData) => void
}

export function ScheduleUploader({ onDataProcessed }: ScheduleUploaderProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  const handleFileUpload = useCallback(
    async (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0]
      if (!file) return

      // Validate file type
      const validTypes = [
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
        "application/vnd.ms-excel", // .xls
        "text/csv", // .csv
      ]

      if (!validTypes.includes(file.type) && !file.name.match(/\.(xlsx|xls|csv)$/i)) {
        setError("Please upload a valid Excel (.xlsx, .xls) or CSV (.csv) file")
        return
      }

      setIsProcessing(true)
      setError(null)
      setSuccess(null)

      try {
        let processedData: ScheduleData

        if (file.type === "text/csv" || file.name.toLowerCase().endsWith(".csv")) {
          console.log("Processing CSV file...")
          processedData = await processCSVFile(file)
        } else {
          console.log("Processing Excel file...")
          processedData = await processExcelFile(file)
        }

        console.log("Processed data:", processedData)

        if (!processedData.allEntries || processedData.allEntries.length === 0) {
          throw new Error("No valid schedule entries found in the file")
        }

        setSuccess(`Successfully processed ${processedData.allEntries.length} schedule entries`)

        // Ensure onDataProcessed is a function before calling it
        if (typeof onDataProcessed === "function") {
          onDataProcessed(processedData)
        } else {
          console.error("onDataProcessed is not a function:", onDataProcessed)
          setError("Internal error: Unable to process data")
        }
      } catch (err) {
        console.error("Error processing file:", err)
        setError(err instanceof Error ? err.message : "Failed to process file")
      } finally {
        setIsProcessing(false)
        // Reset file input
        event.target.value = ""
      }
    },
    [onDataProcessed],
  )

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileSpreadsheet className="h-5 w-5" />
          Upload Schedule File
        </CardTitle>
        <CardDescription>
          Upload an Excel (.xlsx, .xls) or CSV (.csv) file containing your trucking schedule data
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="file-upload">Select File</Label>
          <div className="flex items-center gap-4">
            <Input
              id="file-upload"
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={handleFileUpload}
              disabled={isProcessing}
              className="flex-1"
            />
            <Button
              type="button"
              disabled={isProcessing}
              className="flex items-center gap-2"
              onClick={() => document.getElementById("file-upload")?.click()}
            >
              <Upload className="h-4 w-4" />
              {isProcessing ? "Processing..." : "Browse"}
            </Button>
          </div>
        </div>

        {/* File format information */}
        <div className="text-sm text-muted-foreground space-y-1">
          <p>
            <strong>Supported formats:</strong>
          </p>
          <ul className="list-disc list-inside space-y-1 ml-2">
            <li>Excel files (.xlsx, .xls)</li>
            <li>CSV files (.csv)</li>
          </ul>
          <p className="mt-2">
            <strong>Expected columns:</strong> Job Name, Truck Type, Time, Location, Driver/Truck, Materials, Pit,
            Quantity, etc.
          </p>
        </div>

        {/* Status messages */}
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-green-200 bg-green-50">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        {/* Processing indicator */}
        {isProcessing && (
          <div className="flex items-center justify-center py-8">
            <div className="flex items-center gap-3">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="text-sm text-muted-foreground">Processing file...</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
